package com.iset.site;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Site2025Application {

	public static void main(String[] args) {
		SpringApplication.run(Site2025Application.class, args);
	}

}
